package com.push.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.intra.util.excel.CExcelDocBuild;
import com.push.service.ManagementUserLogTbl_service;

@Controller
public class AccessLog_controller {
	@Autowired
	ManagementUserLogTbl_service managementUserLogTbl_Service;
	
	@RequestMapping("accesslog_page.do")
	public ModelAndView accesslog_page(
			@RequestParam(defaultValue = "accesslog", value = "type") String type,
			@RequestParam(defaultValue = "1", value = "page") int page,
			@RequestParam(defaultValue = "api_access_time", value = "sort") String sort,
			@RequestParam(defaultValue = "desc", value = "direction") String direction,
			@RequestParam(required = false, defaultValue = "0", value = "search_type") int search_type,
			@RequestParam(required = false, defaultValue = "", value = "search_word") String search_word,
			@RequestParam(required = false, defaultValue ="0" ,value = "search_time_type") String search_time_type,
			@RequestParam(required = false, defaultValue = "20190101", value = "start_create_date") String start_create_date,
			@RequestParam(required = false, defaultValue = "20401231", value = "end_create_date") String end_create_date)
		
	{
		ModelAndView mv = new ModelAndView();
		
		List<Map<String, Object>> accesslog_list = null;
		int total = 0;

		switch(type)
		{
		case "accesslog_search":
			String search_word_sql = search_word.trim();
			accesslog_list = managementUserLogTbl_Service.select_accesslog_where_search_type(search_type, search_word_sql, sort, direction, page);
			total = managementUserLogTbl_Service.count_accesslog_where_search_type(search_type, search_word_sql);
		
			mv.addObject("search_type", search_type);
			mv.addObject("search_word", search_word);
			break;
		case "accesslog_search_create_date":
			String _search_time_type = null;
			 
			switch(search_time_type.trim())
			{
				default :
				case "0" :
					{
						mv.setViewName("redirect:" + "/PushAdmin/ddns_page.do");
					};break;
				case "1":
					_search_time_type = "app_access_id";
					break;
				case "2":
					_search_time_type = "cms_access_id";
					break;
				case "3":
					_search_time_type = "device_protocol_type";
					break;
			}
			accesslog_list = managementUserLogTbl_Service.select_accesslog_where_create_date(_search_time_type , start_create_date, end_create_date, sort, direction, page);
			total = managementUserLogTbl_Service.count_accesslog_where_create_date(_search_time_type , start_create_date, end_create_date);
			mv.addObject("start_create_date", start_create_date);
			mv.addObject("end_create_date", end_create_date);
		break;
		case "accesslog":
		default:
			accesslog_list = managementUserLogTbl_Service.select_ManagementUserLogTbl(sort, direction, null,page);
			total = managementUserLogTbl_Service.count_ManagementUserLogTbl(null);
			break;
		}

		int last_page = 0;
		if(total % 10 == 0)
			last_page = total / 10;
		else
			last_page = total / 10 + 1;

		mv.setViewName("accesslog");
		mv.addObject("accesslog_list", accesslog_list);
		mv.addObject("direction", direction);
		mv.addObject("type", type);
		mv.addObject("sort", sort);
		mv.addObject("current_page", page);
		mv.addObject("start_page", (page - 1) / 10 * 10 + 1);
		mv.addObject("end_page", (page - 1) / 10 * 10 + 10);
		mv.addObject("last_page", last_page);

		mv.addObject("search_time_type", search_time_type);
		return mv;
	}

	@RequestMapping("accesslog_excel.xlsx")
	public ModelAndView ddnslog_excel(
			@RequestParam(defaultValue = "accesslog", value = "type") String type,
			@RequestParam(defaultValue = "1", value = "page") int page,
			@RequestParam(defaultValue = "api_access_time", value = "sort") String sort,
			@RequestParam(defaultValue = "desc", value = "direction") String direction,
			@RequestParam(required = false, defaultValue = "0", value = "search_type_excel") int search_type_excel,
			@RequestParam(required = false, defaultValue = "", value = "search_word_excel") String search_word_excel,
		    @RequestParam(required = false, defaultValue ="0" ,value = "search_time_type") String search_time_type,
			@RequestParam(required = false, defaultValue = "20190101", value = "start_create_date_excel") String start_create_date_excel,
			@RequestParam(required = false, defaultValue = "20401231", value = "end_create_date_excel") String end_create_date_excel)
		
	{
		ModelAndView mv = new ModelAndView();
		final String labels[] = {"No,", "맥 주소", "등록타입","APP ACCESS ID", "APP DATE" , "CMS ACCESS ID" , "CMS DATE", "DEVICE PROTOCOL TYPE" , "DEVICE PROTOCOL DATE"};
		final int columnWidth[] = {10, 30, 30, 50, 50, 50, 50, 50, 50};
		
		CExcelDocBuild excelBuilder = new CExcelDocBuild(labels, columnWidth , "Access Log");
		List<Map<String, Object>> accesslog = null;
		long time = System.currentTimeMillis();
		SimpleDateFormat dayTime = new SimpleDateFormat("yyyyMMddHHmmss");
		String str = type + dayTime.format(new Date(time));
		String fileName = "[" + str +"]" + ".xlsx";
		String search_word_sql = "";String _search_time_type = null;
		
		try {
		switch(type)
		{
		case "accesslog_search_create_date_all":
		 	switch(search_time_type.trim())
			{
				default :
				case "0" :
					{
						mv.setViewName("redirect:" + "/PushAdmin/ddns_page.do");
					};break;
				case "1":
					_search_time_type = "app_access_id";
					break;
				case "2":
					_search_time_type = "cms_access_id";
					break;
				case "3":
					_search_time_type = "device_protocol_type";
					break;
			}
			
			{
				// 향후 Handler구현으로 변경
				int offset = -1;
				excelBuilder.createNewSheet(0);
				while (
						(accesslog = managementUserLogTbl_Service.select_accesslog_where_create_date_excel(_search_time_type, start_create_date_excel, end_create_date_excel,sort, direction , offset)) != null 
						&& accesslog.size() > 0 ) {
					offset -= 100000;
					excelBuilder.addRowList(accesslog);
				}
				}
			break;
		 
		case "accesslog_search_create_date":
			
			switch(search_time_type.trim())
			{
				default :
				case "0" :
					{
						mv.setViewName("redirect:" + "/PushAdmin/ddns_page.do");
					};break;
				case "1":
					_search_time_type = "app_access_id";
					break;
				case "2":
					_search_time_type = "cms_access_id";
					break;
				case "3":
					_search_time_type = "device_protocol_type";
					break;
			}
			accesslog = managementUserLogTbl_Service.select_accesslog_where_create_date_excel(_search_time_type , start_create_date_excel, end_create_date_excel, sort, direction, page);
			if(accesslog != null) {
				//	System.out.println(" \n" + ddnslog_list.size());
					excelBuilder.createNewSheet(0);
					excelBuilder.addRowList(accesslog);
				}
			break;
		case "accesslog_search_all":
			search_word_sql = search_word_excel;
			{
				// 향후 Handler구현으로 변경
				int offset = -1;
				excelBuilder.createNewSheet(0);
				while (
						(accesslog = managementUserLogTbl_Service.select_accesslog_where_search_type_excel(search_type_excel, search_word_sql, sort, 
								direction , offset)) != null 
						&& accesslog.size() > 0 ) {
					offset -= 100000;
					excelBuilder.addRowList(accesslog);
				}
				}
			break;
		case "accesslog_search":
			search_word_sql = search_word_excel;
			accesslog = managementUserLogTbl_Service.select_accesslog_where_search_type_excel(search_type_excel, search_word_sql, sort,
					direction, page);
			if(accesslog != null) {
				//	System.out.println(" \n" + ddnslog_list.size());
					excelBuilder.createNewSheet(0);
					excelBuilder.addRowList(accesslog);
				}
			break;
		case "accesslog_all":{
			// 향후 Handler구현으로 변경 또는 시트를 추가 하는 방식으로 교체
			int offset = -1;
			excelBuilder.createNewSheet(0);
			while (
					(accesslog = managementUserLogTbl_Service.select_accesslog_excel(sort, direction , offset)) != null 
					&& accesslog.size() > 0 ) {
				offset -= 100000;
				excelBuilder.addRowList(accesslog);
			}
			}
			break;
		case "acesslog":
		default:
	 
			accesslog = managementUserLogTbl_Service.select_accesslog_excel(sort, direction, page);
			if(accesslog != null) {
				//	System.out.println(" \n" + ddnslog_list.size());
					excelBuilder.createNewSheet(0);
					excelBuilder.addRowList(accesslog);
				}
			break;
		}
		}catch(Exception e)
		{
		//	e.printStackTrace();
		}
		
	
		RequestAttributes requestAttributes = RequestContextHolder
				.getRequestAttributes();
		HttpServletRequest httpServletRequest = ((ServletRequestAttributes) requestAttributes)
				.getRequest();
		HttpServletResponse httpServelResponse = ((ServletRequestAttributes) requestAttributes)
				.getResponse();
		HttpServletResponse response = httpServelResponse;
		// response.setContentType(getContentType());
		response.setBufferSize(512 * 1024);

		excelBuilder.setExcelFileName(str);
		String userAgent = httpServletRequest.getHeader("User-Agent");
		// logger.debug(excelBuilder.getExcelFileName().toString());
		try {
			if (userAgent.indexOf("MSIE") > -1) {

				fileName = URLEncoder.encode(fileName, "utf-8");

			} else {

				fileName = new String(fileName.getBytes("utf-8"), "iso-8859-1");

			}
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			//logger.debug(e.getLocalizedMessage());
		}

		// response.setContentType("application/octect-stream; charset=utf-8");
		response.setHeader("Content-Disposition",
				"attachment; filename=\"" + fileName + "\";");

		response.setContentType(
				"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		// response.setHeader("Content-Transfer-Encoding", "binary");
		response.setHeader("Pragma", "public");
		response.setHeader("Expires", "0");
		response.setHeader("Cache-Control",
				"no-cache, no-store, must-revalidate");
		response.setHeader("Set-Cookie", "fileDownload=true; path=/");
		mv.addObject("dataMap", excelBuilder);
		mv.setViewName("excelXlsx");
		
		return mv;
	}
}
