package com.ddns.model;

public class Commodity
{
	private String code;
	private int auto_reg_swcontroller;

	public Commodity()
	{
		super();
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public int getAuto_reg_swcontroller() {
		return auto_reg_swcontroller;
	}

	public void setAuto_reg_swcontroller(int auto_reg_swcontroller) {
		this.auto_reg_swcontroller = auto_reg_swcontroller;
	}
}
