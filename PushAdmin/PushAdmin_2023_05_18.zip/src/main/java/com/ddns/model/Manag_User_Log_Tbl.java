package com.ddns.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Manag_User_Log_Tbl implements AutoCloseable {
    public String convertObjectToJsonString( ) {
        ObjectMapper mapper = new ObjectMapper();
        String jsonStr = null;
        try {
          jsonStr = mapper.writeValueAsString(this);
        } catch (JsonProcessingException e) {
           e.printStackTrace();
        }
        return jsonStr;
      }
    public Integer getIdx_num() {
        return idx_num;
    }

    public void setIdx_num(Integer idx_num) {
        this.idx_num = idx_num;
    }

    public String getMac_address() {
        return mac_address;
    }

    public void setMac_address(String mac_address) {
        this.mac_address = mac_address;
    }

    public java.sql.Timestamp getApp_date() {
        return app_date;
    }
    
    public void setApp_date(java.sql.Timestamp app_date) {
        this.app_date = app_date;
    }

    public String getApp_accss_id() {
        return app_access_id;
    }

    public void setApp_accss_id(String app_accss_id) {
        this.app_access_id = app_accss_id;
    }

    public java.sql.Timestamp getCms_date() {
        return cms_date;
    }

    public void setCms_date(java.sql.Timestamp cmd_date) {
        this.cms_date = cmd_date;
    }

    public String getCms_access_id() {
        return cms_access_id;
    }

    public void setCms_access_id(String cmd_access_id) {
        this.cms_access_id = cmd_access_id;
    }
   
    public java.sql.Timestamp getDevice_protocol_date() {
        return device_protocol_date;
    }

    public void setDevice_protocol_date(java.sql.Timestamp device_protocol_date) {
        this.device_protocol_date = device_protocol_date;
    }

    public String getDevice_protocol_type() {
        return device_protocol_type;
    }

    public void setDevice_protocol_type(String device_protocol_type) {
        this.device_protocol_type = device_protocol_type;
    }

    public String getApi_type() {
        return api_type;
    }

    public void setApi_type(String api_type) {
        this.api_type = api_type;
    }
    
    public java.sql.Timestamp getApi_access_time() {
        return api_access_time;
    }
    public void setApi_access_time(java.sql.Timestamp api_access_time) {
        this.api_access_time = api_access_time;
    }

    Integer idx_num = 0;
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    @JsonProperty("mac")
    String mac_address = "";
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss", timezone = "Asia/Seoul")
    @JsonProperty("app_date")
    java.sql.Timestamp app_date;
     @JsonInclude(JsonInclude.Include.NON_EMPTY)
    @JsonProperty("app_access_id")
     String app_access_id="";
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss", timezone = "Asia/Seoul")
    @JsonProperty("cms_date")
    java.sql.Timestamp cms_date;
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    @JsonProperty("cms_access_id")
    String cms_access_id="";
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss", timezone = "Asia/Seoul")
    @JsonProperty("device_protocol_date")
    java.sql.Timestamp device_protocol_date;
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    @JsonProperty("device_protocol_type")
    String device_protocol_type = "";
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    String api_type = "";
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss", timezone = "Asia/Seoul")
    java.sql.Timestamp api_access_time;

    @Override
    public void close() throws Exception {
        idx_num = null;
        mac_address = null;
        app_date = null;
        app_access_id = null;
        cms_date = null;
        cms_access_id = null;
        device_protocol_date = null;
        device_protocol_type = null;
        api_type = null;
        api_access_time = null;
    }
}
