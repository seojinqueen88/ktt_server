package com.ddns.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import com.ddns.model.Manag_User_Log_Tbl;

 
@Mapper
public interface Manag_User_Log_TblDao {
	public int insert_update_ManagementUserLogTbl(Manag_User_Log_Tbl managUserLogTbl);
    public int count_ManagementUserLogTbl(Manag_User_Log_Tbl managUserLogTbl);
    public List<Map<String, Object>> select_ManagementUserLogTbl(Map<String, Object> map);
	public int count_accesslog_where_search_type(Map<String, Object> map);
	public List<Map<String, Object>> select_accesslog_where_search_type(Map<String, Object> map);
	public List<Map<String, Object>> select_accesslog_where_search_type_excel(Map<String, Object> map);
	public int count_accesslog_where_create_date(Map<String, Object> map);
	public List<Map<String, Object>> select_accesslog_where_create_date(Map<String, Object> map);
	public List<Map<String, Object>> select_accesslog_excel(Map<String, Object> map);
	public List<Map<String, Object>> select_accesslog_where_create_date_excel(Map<String, Object> map);
}
