package com.push.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ddns.dao.Manag_User_Log_TblDao;
import com.ddns.model.Manag_User_Log_Tbl;

@Service
public class ManagementUserLogTbl_service {
	@Autowired
	private Manag_User_Log_TblDao managementUserLogTblDao;
	public int count_ManagementUserLogTbl(Manag_User_Log_Tbl managUserLogTbl) {
		if (managUserLogTbl == null) {
			return managementUserLogTblDao
					.count_ManagementUserLogTbl(new Manag_User_Log_Tbl());
		} else {
			return managementUserLogTblDao
					.count_ManagementUserLogTbl(managUserLogTbl);
		}
	}
	public List<Map<String, Object>> select_ManagementUserLogTbl(String sort,
			String direction, Manag_User_Log_Tbl managUserLogTbl) {
		Map<String, Object> map = new HashMap<>();
		map.put("sort", sort);
		map.put("direction", direction);
		if (managUserLogTbl.getApi_access_time() != null) {
			map.put("app_date", managUserLogTbl.getApi_access_time());
		}
		if (managUserLogTbl.getCms_date() != null) {
			map.put("cms_date", managUserLogTbl.getCms_date());
		}
		if (managUserLogTbl.getDevice_protocol_date() != null) {
			map.put("device_protocol_date",
					managUserLogTbl.getDevice_protocol_date());
		}
		return managementUserLogTblDao.select_ManagementUserLogTbl(map);
	}

	public List<Map<String, Object>> select_ManagementUserLogTbl(String sort,
			String direction, Manag_User_Log_Tbl managUserLogTbl, int offset) {
		Map<String, Object> map = new HashMap<>();
		map.put("sort", sort);
		map.put("direction", direction);
		if (managUserLogTbl != null) {
			if (managUserLogTbl.getApi_access_time() != null) {
				map.put("app_date", managUserLogTbl.getApi_access_time());
			}
			if (managUserLogTbl.getCms_date() != null) {
				map.put("cms_date", managUserLogTbl.getCms_date());
			}
			if (managUserLogTbl.getDevice_protocol_date() != null) {
				map.put("device_protocol_date",
						managUserLogTbl.getDevice_protocol_date());
			}
		}
		if (offset > 0) {
			map.put("offset",  	((offset - 1) * 10));
		}
		return managementUserLogTblDao.select_ManagementUserLogTbl(map);
	}
	private static final int SEARCHTYPE_MAC = 0;
	private static final int SEARCHTYPE_APP_ACCESS_ID = 1;
	private static final int SEARCHTYPE_CMS_ACCESS_ID = 2;
	private static final int SEARCHTYPE_DEVICE_PROTOCOL_TYPE=3;
	
	public int count_accesslog_where_search_type(int search_type, String search_word)
	{
		Map<String, Object> map = new HashMap<>();
		map.put("search_type", getSearchTypeStr(search_type));
		map.put("search_word", search_word);
		return managementUserLogTblDao.count_accesslog_where_search_type(map);
	}
	

	public List<Map<String, Object>> select_accesslog_where_search_type_excel(int search_type, String search_word, String sort, String direction, int offset)
	{
		Map<String, Object> map = new HashMap<>();
		map.put("search_type", getSearchTypeStr(search_type));
		map.put("search_word", search_word);
		map.put("sort", sort);
		map.put("direction", direction);
		if (offset > 0) {
			map.put("offset",  	((offset - 1) * 10));
		}else if(offset < 0) {
			map.put("offset",  	offset);
		}
		return managementUserLogTblDao.select_accesslog_where_search_type_excel(map);
	}
	public List<Map<String, Object>> select_accesslog_where_search_type(int search_type, String search_word, String sort, String direction, int offset)
	{
		Map<String, Object> map = new HashMap<>();
		map.put("search_type", getSearchTypeStr(search_type));
		map.put("search_word", search_word);
		map.put("sort", sort);
		map.put("direction", direction);
		if (offset > 0) {
			map.put("offset",  	((offset - 1) * 10));
		}
		return managementUserLogTblDao.select_accesslog_where_search_type(map);
	}
	
	public List<Map<String, Object>> select_accesslog_where_create_date_excel(String search_time_type , String start_create_date,String end_create_date, String sort,String direction, int offset)
	{
		Map<String, Object> map = new HashMap<>();
		map.put("start_create_date", start_create_date);
		map.put("end_create_date", end_create_date);
		map.put("sort", sort);
		map.put("direction", direction);
		map.put("search_time_type", search_time_type);
		if (offset > 0) {
			map.put("offset",  	((offset - 1) * 10));
		}else if(offset < 0) {
			map.put("offset",  	offset);
		}
		return managementUserLogTblDao.select_accesslog_where_create_date_excel(map);
	}
	public List<Map<String, Object>> select_accesslog_where_create_date(String search_time_type , String start_create_date,String end_create_date, String sort,String direction, int offset)
	{
		Map<String, Object> map = new HashMap<>();
		map.put("start_create_date", start_create_date);
		map.put("end_create_date", end_create_date);
		map.put("sort", sort);
		map.put("direction", direction);
		map.put("search_time_type", search_time_type);
		if (offset > 0) {
			map.put("offset",  	((offset - 1) * 10));
		}
		return managementUserLogTblDao.select_accesslog_where_create_date(map);
	}
	
	public int count_accesslog_where_create_date(String search_time_type ,String start_create_date,String end_create_date)
	{
		Map<String, Object> map = new HashMap<>();
		map.put("search_time_type", search_time_type);
		map.put("start_create_date", start_create_date);
		map.put("end_create_date", end_create_date);
		return managementUserLogTblDao.count_accesslog_where_create_date(map);
	}
	public List<Map<String, Object>> select_accesslog_excel(String sort, String direction, int offset)
	{
		Map<String, Object> map = new HashMap<>();
		map.put("sort", sort);
		map.put("direction", direction);
		if (offset > 0) {
			map.put("offset",  	((offset - 1) * 10));
		
		}else if(offset < 0) {
			System.out.println("\n"+ 	offset);
			map.put("offset",  	offset);
		}
	
		return managementUserLogTblDao.select_accesslog_excel(map);
	}

	private String getSearchTypeStr(int search_type)
	{
		switch(search_type)
		{
		case SEARCHTYPE_MAC:
			return "mac_address";
		case SEARCHTYPE_APP_ACCESS_ID:
			return "app_access_id";
		case SEARCHTYPE_CMS_ACCESS_ID:
			return "cms_access_id";
		case SEARCHTYPE_DEVICE_PROTOCOL_TYPE:
			return "device_protocol_type";
		}
		return "";
	}
	
}
