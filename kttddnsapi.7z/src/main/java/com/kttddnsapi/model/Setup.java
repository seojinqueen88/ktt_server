package com.kttddnsapi.model;

public class Setup
{
	private String setup_key;
	private String string_value;
	private int int_value;

	public Setup() {
		super();
	}

	public String getSetup_key() {
		return setup_key;
	}

	public void setSetup_key(String setup_key) {
		this.setup_key = setup_key;
	}

	public String getString_value() {
		return string_value;
	}

	public void setString_value(String string_value) {
		this.string_value = string_value;
	}

	public int getInt_value() {
		return int_value;
	}

	public void setInt_value(int int_value) {
		this.int_value = int_value;
	}
}
